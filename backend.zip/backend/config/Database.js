import mongoose from "mongoose";
import dotenv from "dotenv";
const connectDb = async () => {
  // const uri =
  //   "mongodb+srv://sumitpahadiya01:FJANhkwfk8af1S0e@cluster0.1slln.mongodb.net/";
  dotenv.config();
  try {
    const uri = process.env.MONGODB_URI;
    await mongoose.connect(uri, {});
    console.log("Connected to MongoDB");
  } catch (error) {
    console.error("Error connecting to MongoDB:", error.message);
  }
};

export default connectDb;
