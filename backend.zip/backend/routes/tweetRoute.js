import express from "express";
import {
  createTweet,
  deleteTweet,
  getAllTweets,
  getFollowingTweets,
  likeOrDislike,
} from "../controllers/tweetController.js";
import isAuthenticated from "../config/auth.js";
const tweetRouter = express.Router();
tweetRouter.route("/create").post(isAuthenticated, createTweet);
tweetRouter.route("/delete/:id").delete(isAuthenticated, deleteTweet);
tweetRouter.route("/like/:id").put(isAuthenticated, likeOrDislike);
tweetRouter.route("/alltweets/:id").get(isAuthenticated, getAllTweets);
tweetRouter
  .route("/followingtweets/:id")
  .get(isAuthenticated, getFollowingTweets);

export default tweetRouter;
