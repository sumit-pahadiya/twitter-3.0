import { tweet } from "../models/tweetsSchema.js";
import { user } from "../models/userSchema.js";

export const createTweet = async (req, res) => {
  try {
    const { description, id } = req.body;
    if (!description || !id) {
      return res.status(401).json({
        message: "Fields are required",
        success: false,
      });
    }
    const User = await user.findById(id);
    await tweet.create({
      description,
      userId: id,
      userDetails: User,
    });
    return res.status(201).json({
      message: "Tweet created successfully",
      success: true,
    });
  } catch (error) {
    console.log(error);
  }
};
export const deleteTweet = async (req, res) => {
  try {
    const id = req.params.id;
    await tweet.findByIdAndDelete(id);
    return res.status(200).json({
      message: "Tweet deleted successfully",
      success: true,
    });
  } catch (error) {
    console.log(error);
  }
};

export const likeOrDislike = async (req, res) => {
  try {
    const loggedInUserId = req.body.id;
    const tweetId = req.params.id;
    const Tweet = await tweet.findById(tweetId);
    if (Tweet.likes.includes(loggedInUserId)) {
      // dislike
      await tweet.findByIdAndUpdate(tweetId, {
        $pull: { likes: loggedInUserId },
      });
      return res.status(200).json({
        message: "User disliked your tweet.",
      });
    } else {
      // like
      await tweet.findByIdAndUpdate(tweetId, {
        $push: { likes: loggedInUserId },
      });
      return res.status(200).json({
        message: "User liked your tweet.",
      });
    }
  } catch (error) {
    console.log(error);
  }
};

export const getAllTweets = async (req, res) => {
  try {
    const id = req.params.id;
    const loggedInUser = await user.findById(id);
    const loggedInUserTweets = await tweet.find({ userId: id });
    const followingUserTweets = await Promise.all(
      loggedInUser.following.map((otherusers) => {
        return tweet.find({ userId: otherusers });
      })
    );
    return res.status(200).json({
      tweets: loggedInUserTweets.concat(...followingUserTweets),
    });
  } catch (error) {
    console.log(error);
  }
};
export const getFollowingTweets = async (req, res) => {
  try {
    const id = req.params.id;
    const loggedInUser = await user.findById(id);
    const followingUserTweets = await Promise.all(
      loggedInUser.following.map((otherusers) => {
        return tweet.find({ userId: otherusers });
      })
    );
    return res.status(200).json({
      tweets: [].concat(...followingUserTweets),
    });
  } catch (error) {
    console.log(error);
  }
};
